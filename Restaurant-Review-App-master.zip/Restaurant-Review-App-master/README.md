# Restaurant-Review-App
This is a web app that displays various restaurant reviews.
